﻿namespace SOFT562Week18
{
    partial class DatabaseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewfacebookusers = new System.Windows.Forms.DataGridView();
            this.dataGridViewfacebookfriends = new System.Windows.Forms.DataGridView();
            this.dataGridViewMessages = new System.Windows.Forms.DataGridView();
            this.dataGridViewUniversities = new System.Windows.Forms.DataGridView();
            this.dataGridViewWorkplace = new System.Windows.Forms.DataGridView();
            this.comboBoxQueryChoice = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewfacebookusers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewfacebookfriends)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMessages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUniversities)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWorkplace)).BeginInit();

            this.SuspendLayout();
            // 
            // dataGridViewfacebookusers
            // 
            this.dataGridViewfacebookusers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewfacebookusers.Location = new System.Drawing.Point(20, 15);
            this.dataGridViewfacebookusers.Name = "dataGridViewfacebookusers";
            this.dataGridViewfacebookusers.RowHeadersWidth = 51;
            this.dataGridViewfacebookusers.RowTemplate.Height = 24;
            this.dataGridViewfacebookusers.Size = new System.Drawing.Size(368, 370);
            this.dataGridViewfacebookusers.TabIndex = 0;
            // 
            // dataGridViewfacebookfriends
            // 
            this.dataGridViewfacebookfriends.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewfacebookfriends.Location = new System.Drawing.Point(20, 15);
            this.dataGridViewfacebookfriends.Name = "dataGridViewfacebookfriends";
            this.dataGridViewfacebookfriends.RowHeadersWidth = 51;
            this.dataGridViewfacebookfriends.RowTemplate.Height = 24;
            this.dataGridViewfacebookfriends.Size = new System.Drawing.Size(368, 370);
            this.dataGridViewfacebookfriends.TabIndex = 1;
            //
            // dataGridviiewMessages
            //
            this.dataGridViewMessages.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMessages.Location = new System.Drawing.Point(414, 15);
            this.dataGridViewMessages.Name = "dataGridViewMessages";
            this.dataGridViewMessages.RowHeadersWidth = 51;
            this.dataGridViewMessages.RowTemplate.Height = 24;
            this.dataGridViewMessages.Size = new System.Drawing.Size(364, 370);
            this.dataGridViewMessages.TabIndex = 2;
            //
            // dataGridviewUniversities
            //
            this.dataGridViewUniversities.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUniversities.Location = new System.Drawing.Point(20, 15);
            this.dataGridViewUniversities.Name = "dataGridViewUnversities";
            this.dataGridViewUniversities.RowHeadersWidth = 51;
            this.dataGridViewUniversities.RowTemplate.Height = 24;
            this.dataGridViewUniversities.Size = new System.Drawing.Size(368, 370);
            this.dataGridViewUniversities.TabIndex = 3;
            //
            // dataGridviesWorkplace
            //
            this.dataGridViewWorkplace.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWorkplace.Location = new System.Drawing.Point(20, 15);
            this.dataGridViewWorkplace.Name = "dataGridViewWorkplace";
            this.dataGridViewWorkplace.RowHeadersWidth = 51;
            this.dataGridViewWorkplace.RowTemplate.Height = 24;
            this.dataGridViewWorkplace.Size = new System.Drawing.Size(368, 370);
            this.dataGridViewWorkplace.TabIndex = 4;
            // 
            // comboBoxQueryChoice
            // 
            this.comboBoxQueryChoice.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxQueryChoice.FormattingEnabled = true;
            this.comboBoxQueryChoice.Items.AddRange(new object[] {
            "facebookusers",
            "facebookfriends",
            "Messages",
            "Universities",
            "Workplace"});
            this.comboBoxQueryChoice.Location = new System.Drawing.Point(20, 404);
            this.comboBoxQueryChoice.Name = "comboBoxQueryChoice";
            this.comboBoxQueryChoice.Size = new System.Drawing.Size(757, 34);
            this.comboBoxQueryChoice.TabIndex = 5;
            this.comboBoxQueryChoice.SelectedIndexChanged += new System.EventHandler(this.comboBoxQueryChoice_SelectedIndexChanged);
            // 
            // DatabaseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.comboBoxQueryChoice);
            this.Controls.Add(this.dataGridViewMessages);
            this.Controls.Add(this.dataGridViewfacebookusers);
            this.Controls.Add(this.dataGridViewfacebookfriends);
            this.Controls.Add(this.dataGridViewUniversities);
            this.Controls.Add(this.dataGridViewWorkplace);
            this.Name = "DatabaseForm";
            this.Text = "Database Form Test";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewfacebookusers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewfacebookfriends)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMessages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUniversities)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMessages)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewfacebookusers;
        private System.Windows.Forms.DataGridView dataGridViewfacebookfriends;
        private System.Windows.Forms.DataGridView dataGridViewMessages;
        private System.Windows.Forms.DataGridView dataGridViewUniversities;
        private System.Windows.Forms.DataGridView dataGridViewWorkplace;
        private System.Windows.Forms.ComboBox comboBoxQueryChoice;
    }
}
