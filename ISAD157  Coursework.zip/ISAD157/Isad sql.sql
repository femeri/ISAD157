Create Table facebookusers
(
UserId int NOT NULL Primary Key,
Firstname varchar (45),
Lastname varchar (45),
Gender varchar (45),
Hometown varchar(150),
City varchar (45)
);

Create Table facebookfriends
(
UserId int,
FriendId int,
Primary Key (UserId, FriendId),
foreign key (UserId) references facebookusers (UserId),
foreign key (FriendId) references Facebookusers (UserId)
); 

Create table Messages
(
SenderId int,
ReceiverId int,
DateAndTime Varchar(50),
Messages varchar (150),
primary key (SenderId, ReceiverId, DateAndTime, Messages),
foreign key (SenderId) references facebookusers (UserId)
);

Create table Universities
(
StudentId int not null,
University varchar (155) not null,
primary key (StudentId, University),
foreign key (StudentId) references facebookusers(UserId)
);

Create table Workplace
(
UserId int not null,
Workplace varchar (45) not null,
primary key (UserId, Workplace),
foreign key (UserId) references facebookusers (UserId)
);

select * from facebookfriends;
select * from facebookusers;
select * from Messages;
select * from Universities;
select * from Workplace;
SELECT * FROM ISAD157_femeri.facebookfriends;



